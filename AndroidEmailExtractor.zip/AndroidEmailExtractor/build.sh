#!/bin/bash

# Android Email Extractor Build Script
echo "📧 Android E-posta Ayıklayıcı - Build Script"
echo "=========================================="

# Check if gradlew exists
if [ ! -f "./gradlew" ]; then
    echo "❌ gradlew bulunamadı!"
    echo "Lütfen Android Studio ile projeyi açın ve sync edin."
    exit 1
fi

# Make gradlew executable
chmod +x ./gradlew

echo "🔧 Cleaning previous builds..."
./gradlew clean

echo "📱 Debug APK oluşturuluyor..."
./gradlew assembleDebug

if [ $? -eq 0 ]; then
    echo "✅ Debug APK başarıyla oluşturuldu!"
    echo "📁 APK konumu: app/build/outputs/apk/debug/app-debug.apk"
    
    echo ""
    echo "📋 Kurulum talimatları:"
    echo "1. APK dosyasını cihazınıza kopyalayın"
    echo "2. 'Bilinmeyen kaynaklardan yüklemeye izin ver' aktifleştirin"
    echo "3. APK dosyasına dokunun ve kurun"
    echo ""
    echo "🚀 Uygulamayı başlatın ve 'Overlay İzni Ver' butonuna dokunun!"
else
    echo "❌ Build hatası!"
    echo "Lütfen Android Studio ile kontrol edin."
    exit 1
fi