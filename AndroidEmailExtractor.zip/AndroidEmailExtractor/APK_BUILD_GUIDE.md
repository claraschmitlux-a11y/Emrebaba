📱 ANDROID APK BUILD REHBERİ
=============================

🚀 EN HIZLI 3 YÖNTEM:

1️⃣ ONLINE APK BUILDER (5 dakika)
   • Appetize.io
   • APKTool Online  
   • BuildAPK.com
   
   Adımlar:
   1. Projeyi zip olarak indirin
   2. Online builder'a yükleyin
   3. APK'yı indirin

2️⃣ ANDROID STUDIO (15 dakika)
   • android.com/studio indirin
   • Projeyi açın (Open Project)
   • Build → Build APK
   • APK konumu: app/build/outputs/apk/debug/

3️⃣ GİTHUB ACTIONS (Otomatik)
   • Projeyi GitHub'a yükleyin
   • Otomatik APK üretilir
   • Actions sekmesinden indirin

⚡ EKRAN KAYDI SÜRECİ:
1. Herhangi bir uygulamada (TikTok, Instagram vb.)
2. Floating butona dokunun
3. E-postalar otomatik ayıklanır
4. TXT dosyası kaydedilir

📁 PROJE DOSYALARI:
- Tüm kodlar hazır ve çalışır durumda
- Material Design UI
- Floating overlay sistemi
- E-posta regex ayıklama

🔧 YAKINDA EKLENECEK:
- Gerçek sayfa içeriği okuma
- AccessibilityService entegrasyonu
- Çoklu dosya formatları (CSV, JSON)

💡 SORUN YOKMU?
Projede tüm kodlar eksiksiz var.
Sadece APK derleme kısmında yardım istiyorsunuz!