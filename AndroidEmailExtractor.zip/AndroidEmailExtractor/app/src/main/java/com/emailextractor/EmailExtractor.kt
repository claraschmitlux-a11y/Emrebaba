package com.emailextractor

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

object EmailExtractor {
    // E-posta regex pattern'i
    private val EMAIL_PATTERN = Pattern.compile(
        "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}",
        Pattern.CASE_INSENSITIVE
    )

    /**
     * Metinden e-posta adreslerini ayıklar
     */
    fun extractEmails(text: String): List<String> {
        val emails = mutableListOf<String>()
        val matcher = EMAIL_PATTERN.matcher(text)
        
        while (matcher.find()) {
            val email = matcher.group()
            if (!emails.contains(email)) {
                emails.add(email)
            }
        }
        
        return emails
    }

    /**
     * E-postaları TXT dosyasına kaydeder
     */
    fun saveEmailsToFile(context: Context, emails: List<String>): Boolean {
        return try {
            val directory = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            if (directory != null && directory.exists()) {
                val timestamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.getDefault())
                    .format(Date())
                val fileName = "extracted_emails_$timestamp.txt"
                val file = File(directory, fileName)

                FileWriter(file).use { writer ->
                    writer.write("E-posta Ayıklama Raporu\n")
                    writer.write("Tarih: ${Date()}\n")
                    writer.write("Toplam e-posta: ${emails.size}\n")
                    writer.write("=" .repeat(50) + "\n\n")

                    emails.forEachIndexed { index, email ->
                        writer.write("${index + 1}. $email\n")
                    }

                    writer.write("\n" + "=" .repeat(50) + "\n")
                    writer.write("Dosya: ${file.name}\n")
                    writer.write("Konum: ${file.absolutePath}\n")
                }

                true
            } else {
                false
            }
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * Basit e-posta doğrulama
     */
    fun isValidEmail(email: String): Boolean {
        return EMAIL_PATTERN.matcher(email).matches()
    }

    /**
     * E-postaları filtrele (geçerli olanları al)
     */
    fun filterValidEmails(emails: List<String>): List<String> {
        return emails.filter { isValidEmail(it) }
    }

    /**
     * E-postaları domain'e göre grupla
     */
    fun groupEmailsByDomain(emails: List<String>): Map<String, List<String>> {
        return emails.groupBy { email ->
            email.substringAfter("@")
        }
    }
}