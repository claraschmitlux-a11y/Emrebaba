# E-posta Ayıklayıcı - Android Uygulaması

## 📧 Uygulama Hakkında

Bu Android uygulaması, diğer uygulamaların üstünde çalışan floating buton ile e-posta adreslerini otomatik olarak ayıklayan ve TXT dosyasına kaydeden bir araçtır.

## ✨ Özellikler

- **Floating Buton**: Diğer uygulamaların üstünde görünen buton
- **E-posta Ayıklama**: Regex ile doğru e-posta formatlarını bulur
- **TXT Kaydetme**: Bulunan e-postaları tarihli dosyalara kaydeder
- **Overlay İzni**: Diğer uygulamalar üzerinde çalışma desteği
- **Modern UI**: Material Design ile şık arayüz
- **Kullanım Kolaylığı**: Tek dokunuşla işlem

## 🚀 APK Almak için 3 Pratik Yöntem

### Yöntem 1: Online APK Builders (En Kolay)
**Appetize.io, APKBuilder, Android Studio Online**
1. Proje dosyalarını zip olarak indirin
2. Online Android APK builder sitesine yükleyin
3. APK dosyasını indirin

### Yöntem 2: Android Studio (En Güvenilir)
**Gereksinimler:**
- Android Studio (Ücretsiz)
- JDK 11+
- Android SDK

**Adımlar:**
1. Android Studio'yu kurun
2. "Open an Existing Project" → `AndroidEmailExtractor` klasörü seçin
3. Gradle sync'i bekleyin
4. Build → Build APK(s)
5. APK: `app/build/outputs/apk/debug/app-debug.apk`

### Yöntem 3: GitHub Actions (Otomatik)
**Otomatik APK üretimi:**
1. Projeyi GitHub'a yükleyin
2. GitHub Actions otomatik APK üretecek
3. Actions sekmesinden APK dosyasını indirin

### Yöntem 4: Cloud IDE (Hızlı)
**Codespaces, Gitpod gibi bulut IDE'ler:**
1. GitHub'a proje yükleyin
2. Cloud IDE'de açın
3. Terminal'de: `./gradlew assembleDebug`
4. APK indirin

## 📱 Kullanım

### İlk Kurulum
1. Uygulamayı başlatın
2. **"Overlay İzni Ver"** butonuna dokunun
3. İzin verin ve ana ekrana dönün

### Floating Buton Başlatma
1. **"Floating Butonu Başlat"** butonuna dokunun
2. Uygulama arka planda çalışmaya başlayacak
3. Floating buton ekranda görünecek

### E-posta Ayıklama
1. Herhangi bir uygulamaya (TikTok, Instagram, web tarayıcı) gidin
2. E-posta bulunan sayfa/profilde olduğunuzdan emin olun
3. Floating butona dokunun
4. Uygulama e-postaları ayıklayıp kaydedecek

### Dosyaları Bulma
```
Android/data/com.emailextractor/files/Download/
extracted_emails_YYYY-MM-DD_HH-mm-ss.txt
```

## 🔧 Teknik Detaylar

### Minimum Gereksinimler
- **Android**: 5.0 (API 21) ve üzeri
- **İzinler**: Overlay, Storage, Foreground Service
- **RAM**: 50MB

### Kullanılan Teknolojiler
- **Kotlin**: Modern Android geliştirme
- **Material Components**: UI/UX
- **WindowManager**: Floating window
- **File System**: TXT kaydetme
- **Regex**: E-posta pattern matching

### Dosya Yapısı
```
AndroidEmailExtractor/
├── app/
│   ├── src/main/
│   │   ├── java/com/emailextractor/
│   │   │   ├── MainActivity.kt
│   │   │   ├── FloatingService.kt
│   │   │   └── EmailExtractor.kt
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   ├── drawable/
│   │   │   ├── values/
│   │   │   └── mipmap/
│   │   └── AndroidManifest.xml
│   └── build.gradle
└── build.gradle
```

## ⚠️ Notlar

### Güvenlik
- Uygulama sadece kendi klasörüne yazar
- İnternet izni yok (gizlilik)
- Kullanıcı verileri toplamaz

### Sınırlamalar
- E-posta ayıklama şimdilik simülasyon (gerçek uygulama için AccessibilityService gerekir)
- Sadece görünür metinlerden ayıklama yapabilir
- Root izni gerekmez

### Gelecek Güncellemeler
- [ ] Gerçek sayfa içeriği okuma
- [ ] Toplu e-posta işleme
- [ ] Farklı dosya formatları
- [ ] Export seçenekleri

## 🛠️ Geliştirici Notları

### Proje Derleme
```bash
# Debug build
./gradlew assembleDebug

# Release build
./gradlew assembleRelease

# Test çalıştırma
./gradlew test
```

### Bağımlılıklar
```gradle
implementation 'androidx.core:core-ktx:1.12.0'
implementation 'androidx.appcompat:appcompat:1.6.1'
implementation 'com.google.android.material:material:1.10.0'
implementation 'androidx.constraintlayout:constraintlayout:2.1.4'
```

### Debugging
- Logcat: `FloatingService` tag
- Uygulama durumu: Settings.canDrawOverlays()
- File operations: Environment.getExternalStorageDirectory()

## 📞 Destek

Bu uygulama açık kaynak projesidir. Katkılarınızı bekliyoruz!

## 📄 Lisans

MIT License - Ücretsiz kullanım

---

**Not**: Bu uygulama eğitim amaçlı geliştirilmiştir. Ticari kullanım için uygun lisansları alınız.